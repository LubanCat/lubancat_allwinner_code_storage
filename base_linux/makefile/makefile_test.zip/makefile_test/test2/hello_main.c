#include "hello_func.h"

int main()
{
    hello_func();
    return 0;
}